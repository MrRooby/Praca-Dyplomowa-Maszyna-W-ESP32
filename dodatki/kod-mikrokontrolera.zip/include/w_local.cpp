#include "w_local.h"

uint8_t W_Local::getPaOAddr()
{
    return 0;
}